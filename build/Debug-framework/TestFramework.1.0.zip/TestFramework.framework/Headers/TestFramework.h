//
//  TestFramework.h
//  TestFramework
//
//  Created by 長谷川 敏行 on 2013/09/05.
//  Copyright (c) 2013年 長谷川 敏行. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestFramework : NSObject

- (void) hello;

@end
